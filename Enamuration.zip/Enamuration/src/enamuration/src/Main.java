package enamuration.src;
import java.util.Date;
public class Main {
    public static void main(String[] args)
    {
        
        Teacher teacher1=new Teacher("Sally","March 1,1980","ULCA",15000.0,10);
        System.out.println(teacher1.getSalary());
//        teacher1.printinfo();
        Date mAssignmentDueDate=new Date();
        Assignment joeyAssignment =new Assignment("Calculus Homework","Calculus",mAssignmentDueDate);
        Student joey=new Student("Joey","02/04/2009",4.0);
//        joey.setCurrentAssignment(joeyAssignment);
//        joey.setCurrentAssignment("Biology Homework");
//        joey.printAssignmentinfo();
//        System.out.println(joey.toString());
//        joey.addAssignments(
//        new Assignment("Bio HW","Biology",new Date()),
//        new Assignment("Computer Science Lab","C.S",new Date()),
//        new Assignment("Computer Science Lab","C.S",new Date()),
//        new Assignment("Computer Science Lab","C.S",new Date()),
//        new Assignment("Computer Science Lab","C.S",new Date())
//        );
//    
    
//    joey.printinfo();
    
//    Calender calender=new Calender.getInstance();
//    calender.set(Calender.YEAR,1965);
//    calender.set(Calender.Month,Calender.MARCH);
//    calender.set(Calender.DATE,23);
//    
//    principal principal1=new principal("Alex Smith","03/23/1965",new Date());
//    principal1.doSomething();
//    Teacher teacher=new Teacher("Alexis Brown","05/07/1980","San Diego State",50000,20);
//   
//   doSomething(joey);
//   doSomething(principal1);
//   doSomething(teacher);
    
    Assignment[] assignments={ 
        new Assignment("Bio HW","Biology",new Date(System.currentTimeMillis() - 24*60*60*1000)),
        new Assignment("Computer Science Lab","C.S",new Date()),
        new Assignment("Computer Science Lab","C.S",new Date()),
        new Assignment("Computer Science Lab","C.S",new Date()),
        new Assignment("Computer Science Lab","C.S",new Date())
    };
    
    
    Assignment farthestInPast=Assignment.getFarthestInPastAssignment(assignments);
    System.out.println(farthestInPast.getName());
    int defScore=Assignment.ASSIGNMENT_DEFAULT_SCORE;
    }
// public static void doSomething(Person person){
//     if(person instanceof Student)
//     {
//         System.out.println("This Person is a Student");
//     }
//     else if(person instanceof Teacher)
//     {       
//             Teacher castedTeacher=(Teacher) person;
//             System.out.print("This person is a Teacher who has a salary of "+ castedTeacher.getSalary());
//             }
//     else if(person instanceof principal){
//         System.out.println("This person is a Principal");
//     }
// }
}