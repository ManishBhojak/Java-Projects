package enamuration.src;

import java.util.Date;

public class principal extends Person{
    private Date mJoinDate;
    public principal(String personName,String personBirthDate,Date joinDate){
        super(personName,personBirthDate);
        mJoinDate=joinDate;
        
    }
    public void doSomething(){
        super.doSomething();
        System.out.println("This person is a Principal");
    }
}
