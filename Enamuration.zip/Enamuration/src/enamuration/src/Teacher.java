package enamuration.src;
public class Teacher extends Person{
private String mschool;
private double msalary;
private int mNumYearsAtSchool;
public Teacher(String name,String birthDate,String school,double salary,int numYearsAtSchool){
      super(name,birthDate);
      mschool=school;
      msalary=salary;
      mNumYearsAtSchool=numYearsAtSchool;
      
}
@Override
public void printinfo(){
    System.out.println("I am a Teacher and I was born on"+getBirthDate());
}
public double getSalary(){
    return mNumYearsAtSchool *1000 + msalary;
}
}
