package enamuration.src;

import java.util.Date;

public class Assignment {
private String mName,mClassName;
private Date mAssignmentDueDate;

public Assignment(String name,String className,Date assignmentDueDate){
    mName=name;
    mClassName=className;
    mAssignmentDueDate=assignmentDueDate;
}
public static final int ASSIGNMENT_DEFAULT_SCORE=20;
public static Assignment getFarthestInPastAssignment(Assignment[] assignments){
    long date=Long.MAX_VALUE;
    Assignment closestAssignment=null;
    for(Assignment assignment : assignments){
        if(assignment.mAssignmentDueDate.getTime()< date){
        date = assignment.mAssignmentDueDate.getTime();
        closestAssignment=assignment;
        }
    }
         return closestAssignment;
}
public String getName(){
    return mName;
}
public String setName(String mName){
    return this.mName=mName;
}
public String getClassName(){
    return mClassName;
}
public String setClassName(String mClassName){
    return this.mClassName=mClassName;
}
public Date getAssignmentDueDate(){
    return mAssignmentDueDate;
}
public Date setAssignmentDueDate(Date mAssignmentDueDate){
    return this.mAssignmentDueDate=mAssignmentDueDate;
}
}

