package enamuration.src;

import java.util.Date;

public class Person {
    private String name,birthdate;
    public Person(String personname,String date){
        name=personname;
        birthdate=date;
    }
    public void printinfo(){
      System.out.println("I am a person"+" and I am born on "+birthdate);
    }
    public void doSomething(){
        Assignment assignment= new Assignment("","",new Date());
    }
    public String getName()
    {
        return name;
        
    }
    public void setName(String name){
    this.name=name;
    }
    public String getBirthDate(){
        return birthdate;
}
    public void setBirthDate(String birthDate){
        this.birthdate=birthdate;
    }
}