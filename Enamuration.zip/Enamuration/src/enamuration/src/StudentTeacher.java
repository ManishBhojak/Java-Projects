package enamuration.src;
public  class StudentTeacher extends Teacher {
    private String mStudentTeacherSchool;
    public StudentTeacher(String name,String birthDate,String school,double salary,int numYearsAtSchool,String StudentTeacherSchool){
    super(name,birthDate,school,salary,numYearsAtSchool);
    mStudentTeacherSchool = StudentTeacherSchool;
    }
    }

