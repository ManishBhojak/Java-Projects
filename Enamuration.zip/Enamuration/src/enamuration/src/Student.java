package enamuration.src;

import java.util.Date;

public class Student extends Person
{
 private double mgpa;
 private Assignment mCurrentAssignment;
 public Student(String Sname, String date,double gpa)
 {
     super(Sname,date);
     mgpa=gpa;
 }
 @Override
 public void printinfo(){
     System.out.println("See? I'm in the Student class now");
 } 
 public void printAssignmentinfo(){
     if(mCurrentAssignment!=null){
         System.out.println(mCurrentAssignment.getName()+" "+mCurrentAssignment.getAssignmentDueDate());
     }
 }
 @Override
public String toString(){
return getName()+" "+mgpa;
}
public void setCurrentAssignment(Assignment assignment){
mCurrentAssignment=assignment;
}
public void setCurrentAssignment(String assignmentName){
    
    mCurrentAssignment=new Assignment(assignmentName,"Default Class",new Date());
}

    
}
 


